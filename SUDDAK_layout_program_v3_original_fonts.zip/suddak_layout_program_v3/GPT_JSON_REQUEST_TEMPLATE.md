# GPT에게 문항 생성을 요청할 때 사용할 JSON 양식

아래 지시문을 새 채팅에 그대로 붙여 넣고, 필요한 문항 수와 단원만 바꿔서 사용하면 됩니다.

```text
첨부한 수딱 조판 프로그램의 JSON 규격 `suddak-layout-v2`에 맞추어 문제 데이터를 작성해 줘.
반드시 JSON 하나만 출력하고, 설명 문장이나 마크다운은 출력하지 마.

규칙:
1. 최상위 `schema_version`은 반드시 `suddak-layout-v2`로 한다.
2. `pages`의 각 원소는 `type`을 가진다.
   - 예제/유제: `example_exercise`
   - Level 1: `level1`
   - Level 2: `level2`
   - Level 3: `level3`
   - 대표 기출: `past_exam`
3. 수식은 가능한 한 `$...$` 인라인 수식 또는 `display_math` 블록으로 작성한다.
4. 긴 수식은 `display_math` 블록으로 분리한다.
5. 그래프나 도형이 필요한 문항은 `figure` 필드를 사용한다.
   - 직접 만든 SVG/PNG 파일이 있으면 `path` 사용
   - 간단한 함수 그래프는 `figure_type: "function_graph"` 사용
6. 객관식은 선택지 5개를 반드시 넣는다.
7. 문항 코드는 `code`에 넣는다.
8. 해설은 `solution_blocks`에 단계별로 작성한다.
9. 원본 EBS 문항의 문장을 그대로 베끼지 말고, 구조와 아이디어만 변형한다.
10. 결과는 JSON 외의 문장을 절대 포함하지 않는다.

출력해야 할 기본 구조:
{
  "schema_version": "suddak-layout-v2",
  "document_title": "파일명_영문또는숫자",
  "book": "2027 수능특강 미적분 변형",
  "unit_code": "07",
  "pages": []
}
```

## 예제/유제 페이지 양식

```json
{
  "type": "example_exercise",
  "example_title": "정적분과 넓이",
  "example_question_blocks": [
    {"type": "text", "content": "함수 $f(x)=x^2-2x+3$에 대하여 다음 값을 구하시오."},
    {"type": "display_math", "latex": "\\int_0^2 f(x)\\,dx"}
  ],
  "example_choices": ["① $\\frac{8}{3}$", "② $\\frac{10}{3}$", "③ $4$", "④ $\\frac{14}{3}$", "⑤ $\\frac{16}{3}$"],
  "guide_blocks": [
    {"type": "text", "content": "함수값의 부호를 확인한 뒤 정적분으로 넓이를 계산한다."}
  ],
  "solution_blocks": [
    {"type": "text", "content": "$f(x)=(x-1)^2+2>0$ 이므로 넓이는 다음과 같다."},
    {"type": "display_math", "latex": "\\int_0^2 (x^2-2x+3)\\,dx=\\frac{14}{3}"}
  ],
  "exercises": [
    {
      "number": 1,
      "code": "[SUD-07-001]",
      "question_blocks": [
        {"type": "text", "content": "함수 $g(x)=x+1$에 대하여 구간 $[0,3]$에서 넓이를 구하시오."}
      ],
      "choices": ["① $6$", "② $7$", "③ $\\frac{15}{2}$", "④ $8$", "⑤ $9$"]
    },
    {
      "number": 2,
      "code": "[SUD-07-002]",
      "question_blocks": [
        {"type": "text", "content": "함수 $h(x)=2x^2$에 대하여 다음 값을 구하시오."},
        {"type": "display_math", "latex": "\\int_1^2 h(x)\\,dx"}
      ],
      "choices": ["① $\\frac{10}{3}$", "② $\\frac{14}{3}$", "③ $\\frac{16}{3}$", "④ $6$", "⑤ $\\frac{20}{3}$"]
    }
  ]
}
```

## Level 페이지 문항 양식

```json
{
  "type": "level2",
  "problems": [
    {
      "number": 1,
      "code": "[SUD-07-L2-01]",
      "question_blocks": [
        {"type": "text", "content": "곡선 $y=x^2$와 직선 $y=2x$가 둘러싸는 부분의 넓이를 구하시오."}
      ],
      "figure": {
        "type": "figure",
        "figure_type": "function_graph",
        "width_px": 480,
        "height_px": 300,
        "x_min": -0.5,
        "x_max": 2.5,
        "y_min": -0.5,
        "y_max": 4.5,
        "functions": [
          {"expr": "x**2", "label": "y=x^2"},
          {"expr": "2*x", "label": "y=2x"}
        ],
        "points": [{"x": 0, "y": 0, "label": "O"}, {"x": 2, "y": 4, "label": "A"}]
      },
      "choices": ["① $\\frac{2}{3}$", "② $1$", "③ $\\frac{4}{3}$", "④ $2$", "⑤ $\\frac{8}{3}$"]
    }
  ]
}
```

## 대표 기출 페이지 양식

```json
{
  "type": "past_exam",
  "trend_note_blocks": [
    {"type": "text", "content": "정적분으로 넓이를 계산하고 그래프 해석과 연결하는 문항이 자주 출제된다."}
  ],
  "problem": {
    "year_tag": "2025학년도 변형",
    "code": "[SUD-PAST-01]",
    "question_blocks": [
      {"type": "text", "content": "두 함수 $y=x^2$와 $y=2x$가 둘러싸는 부분의 넓이를 구하시오."}
    ],
    "choices": ["① $\\frac{1}{3}$", "② $\\frac{2}{3}$", "③ $1$", "④ $\\frac{4}{3}$", "⑤ $2$"]
  },
  "intent_note_blocks": [
    {"type": "text", "content": "교점을 구하고 위쪽 함수와 아래쪽 함수를 구분하여 정적분을 세우는 능력을 평가한다."}
  ],
  "solution_blocks": [
    {"type": "text", "content": "교점은 $x=0,2$이다."},
    {"type": "display_math", "latex": "\\int_0^2 (2x-x^2)\\,dx=\\frac{4}{3}"}
  ]
}
```

## figure 필드 규칙

### 외부 이미지 삽입
```json
{
  "type": "figure",
  "path": "figures/my_diagram.svg",
  "width_px": 480,
  "height_px": 300,
  "align": "center"
}
```

### 함수 그래프 자동 생성
```json
{
  "type": "figure",
  "figure_type": "function_graph",
  "width_px": 480,
  "height_px": 300,
  "x_min": -2,
  "x_max": 3,
  "y_min": -2,
  "y_max": 5,
  "functions": [
    {"expr": "x**2", "label": "y=x^2"},
    {"expr": "2*x", "label": "y=2x"}
  ],
  "points": [
    {"x": 0, "y": 0, "label": "O"},
    {"x": 2, "y": 4, "label": "A"}
  ]
}
```

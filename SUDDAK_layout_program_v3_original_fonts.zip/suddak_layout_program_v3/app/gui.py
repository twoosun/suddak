from __future__ import annotations
import json
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from renderer import SuddakRenderer

class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title('SUDDAK 조판 프로그램 (beta)')
        self.renderer = SuddakRenderer()
        self.input_path = tk.StringVar()
        self.output_dir = tk.StringVar(value=str((Path(__file__).resolve().parents[1]/'output'/'generated').resolve()))
        self._build()

    def _build(self):
        frm = tk.Frame(self.root, padx=12, pady=12)
        frm.pack(fill='both', expand=True)
        tk.Label(frm, text='입력 JSON').grid(row=0, column=0, sticky='w')
        tk.Entry(frm, textvariable=self.input_path, width=60).grid(row=1, column=0, sticky='we', padx=(0,6))
        tk.Button(frm, text='찾기', command=self.pick_input).grid(row=1, column=1)
        tk.Label(frm, text='출력 폴더').grid(row=2, column=0, sticky='w', pady=(10,0))
        tk.Entry(frm, textvariable=self.output_dir, width=60).grid(row=3, column=0, sticky='we', padx=(0,6))
        tk.Button(frm, text='찾기', command=self.pick_output).grid(row=3, column=1)
        btns = tk.Frame(frm)
        btns.grid(row=4, column=0, columnspan=2, sticky='w', pady=12)
        tk.Button(btns, text='JSON 검사', command=self.validate).pack(side='left', padx=(0,8))
        tk.Button(btns, text='조판 실행', command=self.render).pack(side='left', padx=(0,8))
        tk.Button(btns, text='샘플 채우기', command=self.load_sample).pack(side='left')
        self.log = scrolledtext.ScrolledText(frm, width=90, height=25)
        self.log.grid(row=5, column=0, columnspan=2, sticky='nsew')
        frm.columnconfigure(0, weight=1)
        frm.rowconfigure(5, weight=1)

    def write(self, msg: str):
        self.log.insert('end', msg + '\n')
        self.log.see('end')
        self.root.update_idletasks()

    def pick_input(self):
        path = filedialog.askopenfilename(filetypes=[('JSON', '*.json')])
        if path:
            self.input_path.set(path)

    def pick_output(self):
        path = filedialog.askdirectory()
        if path:
            self.output_dir.set(path)

    def load_data(self):
        inp = self.input_path.get().strip()
        if not inp:
            raise ValueError('입력 JSON 파일을 선택하세요.')
        return json.loads(Path(inp).read_text(encoding='utf-8'))

    def validate(self):
        try:
            data = self.load_data()
            self.renderer.validate_data(data)
            self.write('[검사 통과] JSON 형식이 올바릅니다.')
        except Exception as e:
            messagebox.showerror('검사 실패', str(e))
            self.write('[검사 실패] ' + str(e))

    def render(self):
        try:
            data = self.load_data()
            previews, pdf_path = self.renderer.render_document(data, Path(self.output_dir.get()))
            self.write('[조판 완료]')
            for p in previews:
                self.write(f'PNG: {p}')
            self.write(f'PDF: {pdf_path}')
            messagebox.showinfo('완료', f'PDF 생성 완료\n{pdf_path}')
        except Exception as e:
            messagebox.showerror('조판 실패', str(e))
            self.write('[조판 실패] ' + str(e))

    def load_sample(self):
        self.input_path.set(str((Path(__file__).resolve().parents[1]/'samples'/'sample_document_v3.json').resolve()))
        self.write('샘플 JSON 경로를 입력칸에 채웠습니다.')

if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.geometry('900x650')
    root.mainloop()

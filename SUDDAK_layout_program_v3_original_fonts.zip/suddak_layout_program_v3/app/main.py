from __future__ import annotations
import argparse, json
from pathlib import Path
from renderer import SuddakRenderer


def main():
    parser = argparse.ArgumentParser(description='SUDDAK 조판 프로그램(beta)')
    parser.add_argument('--input', required=True, help='입력 JSON 파일 경로')
    parser.add_argument('--output', default='output/generated', help='출력 폴더')
    args = parser.parse_args()

    data = json.loads(Path(args.input).read_text(encoding='utf-8'))
    renderer = SuddakRenderer()
    previews, pdf_path = renderer.render_document(data, Path(args.output))
    print('[완료]')
    print('미리보기 PNG:')
    for p in previews:
        print(f' - {p}')
    print(f'PDF: {pdf_path}')

if __name__ == '__main__':
    main()

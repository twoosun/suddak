from __future__ import annotations
import argparse, json, math, os, re, shutil, tempfile
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from PIL import Image, ImageDraw, ImageFont
from jsonschema import validate
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

ROOT = Path(__file__).resolve().parents[1]
ASSET_ROOT = ROOT / 'suddak_asset_pack_from_clean_pdf'
SHELLS = ASSET_ROOT / 'shells'
SCHEMA_PATH = ROOT / 'schema.json'
FONT_CONFIG_PATH = ROOT / 'font_config.json'
PAGE_SIZE = (1545, 1928)
PAPER_WHITE = (245, 245, 245)
TEXT_BLACK = (18, 18, 18)
EBS_GREEN = (78, 105, 38)


def read_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding='utf-8'))


def first_existing(paths: List[Path | str]) -> Optional[str]:
    for p in paths:
        pp = Path(p)
        if pp.exists():
            return str(pp)
    return None


def load_font_config() -> Dict[str, Any]:
    if FONT_CONFIG_PATH.exists():
        return read_json(FONT_CONFIG_PATH)
    return {}


class FontPack:
    def __init__(self):
        cfg = load_font_config()
        self.cfg = cfg
        body = first_existing([
            ROOT / cfg.get('body_font', ''),
            cfg.get('fallback_windows_body', ''),
            cfg.get('fallback_linux_body', ''),
            '/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc',
            '/usr/share/fonts/truetype/nanum/NanumMyeongjo.ttf',
        ])
        gothic = first_existing([
            ROOT / cfg.get('gothic_font', ''),
            cfg.get('fallback_windows_body', ''),
            '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
            '/usr/share/fonts/truetype/nanum/NanumGothic.ttf',
        ])
        bold = first_existing([
            ROOT / cfg.get('bold_font', ''),
            cfg.get('fallback_windows_bold', ''),
            cfg.get('fallback_linux_bold', ''),
            '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',
            '/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf',
        ])
        self.body_path = body
        self.gothic_path = gothic or body
        self.bold_path = bold or gothic or body
        if not self.body_path:
            raise RuntimeError('사용 가능한 본문 글꼴을 찾지 못했습니다. fonts/body.ttf를 넣어 주세요.')

    def body(self, size: int):
        return ImageFont.truetype(self.body_path, size)

    def gothic(self, size: int):
        return ImageFont.truetype(self.gothic_path, size)

    def bold(self, size: int):
        return ImageFont.truetype(self.bold_path, size)


class MathRenderer:
    def __init__(self):
        cfg = load_font_config()
        rcParams['mathtext.fontset'] = cfg.get('math_fontset', 'stix')
        rcParams['font.family'] = 'STIXGeneral'

    def render(self, latex: str, fontsize: int = 28, dpi: int = 220, color: str = 'black') -> Image.Image:
        latex = latex.strip()
        latex = re.sub(r'\\frac([0-9])([0-9])', r'\\frac{\1}{\2}', latex)
        if not latex:
            return Image.new('RGBA', (1, 1), (255, 255, 255, 0))
        # matplotlib mathtext needs $...$
        text = latex if latex.startswith('$') else f'${latex}$'
        fig = plt.figure(figsize=(0.01, 0.01), dpi=dpi)
        fig.patch.set_alpha(0)
        ax = fig.add_axes([0, 0, 1, 1])
        ax.axis('off')
        t = ax.text(0, 0, text, fontsize=fontsize, color=color, va='bottom', ha='left')
        fig.canvas.draw()
        bbox = t.get_window_extent(renderer=fig.canvas.get_renderer()).expanded(1.08, 1.25)
        w, h = max(1, int(bbox.width)), max(1, int(bbox.height))
        plt.close(fig)
        fig = plt.figure(figsize=(w / dpi, h / dpi), dpi=dpi)
        fig.patch.set_alpha(0)
        ax = fig.add_axes([0, 0, 1, 1])
        ax.axis('off')
        ax.text(0.02, 0.12, text, fontsize=fontsize, color=color, va='bottom', ha='left')
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
        tmp.close()
        fig.savefig(tmp.name, transparent=True, dpi=dpi, bbox_inches='tight', pad_inches=0.02)
        plt.close(fig)
        im = Image.open(tmp.name).convert('RGBA')
        os.unlink(tmp.name)
        return im


class RichText:
    def __init__(self, draw: ImageDraw.ImageDraw, fonts: FontPack, math: MathRenderer):
        self.draw = draw
        self.fonts = fonts
        self.math = math

    def wrap_plain(self, text: str, max_width: int, font: ImageFont.FreeTypeFont) -> List[str]:
        out = []
        for para in str(text).split('\n'):
            para = para.strip()
            if not para:
                out.append('')
                continue
            cur = ''
            for ch in para:
                test = cur + ch
                w = self.draw.textbbox((0, 0), test, font=font)[2]
                if w <= max_width or not cur:
                    cur = test
                else:
                    out.append(cur)
                    cur = ch
            if cur:
                out.append(cur)
        return out

    def line_height(self, font: ImageFont.FreeTypeFont) -> int:
        b = self.draw.textbbox((0, 0), '가나다', font=font)
        return b[3] - b[1] + 10

    def draw_plain_block(self, page: Image.Image, x: int, y: int, max_width: int, text: str, size=28, bold=False, fill=TEXT_BLACK, line_gap=8) -> int:
        font = self.fonts.bold(size) if bold else self.fonts.body(size)
        lines = self.wrap_plain(text, max_width, font)
        lh = self.line_height(font) + line_gap
        for line in lines:
            self.draw.text((x, y), line, font=font, fill=fill)
            y += lh
        return y

    def measure_plain_block(self, max_width: int, text: str, size=28, bold=False, line_gap=8) -> int:
        font = self.fonts.bold(size) if bold else self.fonts.body(size)
        lines = self.wrap_plain(text, max_width, font)
        if not lines:
            return 0
        return len(lines) * (self.line_height(font) + line_gap)

    def draw_math_center(self, page: Image.Image, y: int, latex: str, x1: int, x2: int, fontsize=28) -> int:
        im = self.math.render(latex, fontsize=fontsize)
        max_w = x2 - x1
        if im.width > max_w:
            ratio = max_w / im.width
            im = im.resize((max_w, max(1, int(im.height * ratio))), Image.LANCZOS)
        x = x1 + (max_w - im.width) // 2
        page.paste(im, (x, y), im)
        return y + im.height + 10

    def measure_math(self, latex: str, fontsize=28) -> int:
        im = self.math.render(latex, fontsize=fontsize)
        return im.height + 10


class SuddakRenderer:
    def __init__(self):
        self.schema = read_json(SCHEMA_PATH)
        self.fonts = FontPack()
        self.math = MathRenderer()

    def validate_data(self, data: Dict[str, Any]) -> None:
        validate(data, self.schema)

    def load_shell(self, filename: str) -> Image.Image:
        return Image.open(SHELLS / filename).convert('RGB')

    def save_pdf(self, pages: List[Image.Image], pdf_path: Path):
        c = canvas.Canvas(str(pdf_path), pagesize=PAGE_SIZE)
        for im in pages:
            c.drawImage(ImageReader(im.convert('RGB')), 0, 0, width=PAGE_SIZE[0], height=PAGE_SIZE[1])
            c.showPage()
        c.save()

    def block_height(self, blocks: List[Dict[str, Any]], width: int, text_size=28, math_size=30) -> int:
        fake = Image.new('RGB', (10, 10))
        draw = ImageDraw.Draw(fake)
        rt = RichText(draw, self.fonts, self.math)
        h = 0
        for b in blocks:
            t = b.get('type')
            if t == 'text':
                h += rt.measure_plain_block(width, b.get('content',''), size=b.get('size', text_size))
            elif t == 'display_math':
                h += rt.measure_math(b.get('latex',''), fontsize=b.get('fontsize', math_size)) + b.get('margin_bottom', 4)
            elif t == 'choices':
                h += 55
            elif t == 'figure':
                h += int(b.get('height_px', 260)) + 14
        return h

    def draw_blocks(self, page: Image.Image, draw: ImageDraw.ImageDraw, blocks: List[Dict[str, Any]], x: int, y: int, width: int, text_size=28, math_size=30) -> int:
        rt = RichText(draw, self.fonts, self.math)
        for b in blocks:
            typ = b.get('type')
            if typ == 'text':
                y = rt.draw_plain_block(page, x, y, width, b.get('content',''), size=b.get('size', text_size), bold=b.get('bold', False))
                y += b.get('margin_bottom', 4)
            elif typ == 'display_math':
                y = rt.draw_math_center(page, y, b.get('latex',''), x, x+width, fontsize=b.get('fontsize', math_size))
                y += b.get('margin_bottom', 4)
            elif typ == 'choices':
                choices = b.get('items', [])
                y = self.draw_choices_horizontal(page, draw, x, y, width, choices, fontsize=b.get('fontsize', 25))
                y += b.get('margin_bottom', 4)
            elif typ == 'figure':
                y = self.draw_figure(page, draw, b, x, y, width)
                y += b.get('margin_bottom', 4)
        return y

    def draw_choices_horizontal(self, page: Image.Image, draw: ImageDraw.ImageDraw, x: int, y: int, width: int, choices: List[str], fontsize=24) -> int:
        font = self.fonts.body(fontsize)
        n = max(1, len(choices))
        slot = width // n
        labels = ['①', '②', '③', '④', '⑤']
        max_h = 0
        for i, choice in enumerate(choices[:5]):
            raw = str(choice).strip()
            px = x + slot * i
            draw.text((px, y), labels[i], font=font, fill=TEXT_BLACK)
            content_x = px + 34
            if raw.startswith(tuple(labels)):
                raw = raw[1:].strip()
            if ('\\' in raw) or ('^' in raw) or ('_' in raw):
                im = self.math.render(raw, fontsize=max(18, fontsize-2))
                if im.height > 34:
                    ratio = 34 / im.height
                    im = im.resize((max(1, int(im.width*ratio)), 34), Image.LANCZOS)
                page.paste(im, (content_x, y-4), im)
                max_h = max(max_h, im.height+6)
            else:
                draw.text((content_x, y), raw, font=font, fill=TEXT_BLACK)
                max_h = max(max_h, 36)
        return y + max(42, max_h)

    def draw_figure(self, page: Image.Image, draw: ImageDraw.ImageDraw, spec: Dict[str, Any], x: int, y: int, width: int) -> int:
        if spec.get('figure_type') == 'function_graph':
            im = self.make_graph(spec)
        else:
            path = spec.get('path')
            if not path:
                return y
            p = ROOT / path
            if not p.exists():
                p = Path(path)
            im = Image.open(p).convert('RGBA')
        target_w = int(spec.get('width_px', min(width, 520)))
        target_h = int(spec.get('height_px', 300))
        im.thumbnail((target_w, target_h), Image.LANCZOS)
        align = spec.get('align', 'center')
        if align == 'right':
            px = x + width - im.width
        elif align == 'left':
            px = x
        else:
            px = x + (width - im.width)//2
        page.paste(im, (px, y), im if im.mode == 'RGBA' else None)
        return y + im.height + 10

    def make_graph(self, spec: Dict[str, Any]) -> Image.Image:
        import numpy as np
        w = int(spec.get('width_px', 520)); h = int(spec.get('height_px', 320))
        x_min = float(spec.get('x_min', -3)); x_max = float(spec.get('x_max', 3))
        y_min = float(spec.get('y_min', -3)); y_max = float(spec.get('y_max', 3))
        fig = plt.figure(figsize=(w/150, h/150), dpi=150)
        ax = fig.add_subplot(111)
        xs = np.linspace(x_min, x_max, 600)
        env = {'x': xs, 'np': np, 'sin': np.sin, 'cos': np.cos, 'tan': np.tan, 'exp': np.exp, 'log': np.log, 'sqrt': np.sqrt, 'pi': np.pi}
        for f in spec.get('functions', []):
            try:
                ys = eval(f.get('expr','x'), {'__builtins__': {}}, env)
                ax.plot(xs, ys, linewidth=1.3, label=f.get('label'))
            except Exception:
                pass
        ax.axhline(0, color='black', linewidth=0.8)
        ax.axvline(0, color='black', linewidth=0.8)
        for p in spec.get('points', []):
            ax.scatter([p.get('x',0)], [p.get('y',0)], s=14, color='black')
            if p.get('label'):
                ax.text(p.get('x',0), p.get('y',0), ' '+p.get('label'), fontsize=8)
        ax.set_xlim(x_min, x_max); ax.set_ylim(y_min, y_max)
        ax.grid(True, linewidth=0.3, alpha=0.35)
        if any(f.get('label') for f in spec.get('functions', [])):
            ax.legend(fontsize=7, frameon=False)
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.png'); tmp.close()
        fig.savefig(tmp.name, transparent=True, bbox_inches='tight', pad_inches=0.02)
        plt.close(fig)
        im = Image.open(tmp.name).convert('RGBA')
        os.unlink(tmp.name)
        return im

    def render_example_exercise(self, data: Dict[str, Any]) -> Image.Image:
        page = self.load_shell('example_exercise_shell.png')
        draw = ImageDraw.Draw(page)
        rt = RichText(draw, self.fonts, self.math)
        # 예제 영역: 원본 상단 박스 내부 좌표
        y = 166
        title = data.get('example_title')
        if title:
            draw.text((335, y), title, font=self.fonts.bold(25), fill=TEXT_BLACK)
            y += 52
        y = self.draw_blocks(page, draw, data.get('example_blocks', []), 185, y, 1130, text_size=24, math_size=23)
        # 길잡이/풀이
        self.draw_blocks(page, draw, data.get('guide_blocks', []), 315, 455, 1040, text_size=23, math_size=22)
        self.draw_blocks(page, draw, data.get('solution_blocks', []), 315, 692, 1040, text_size=23, math_size=22)
        # 유제: 원본 박스에 그대로 입력. 회색 배경 없음
        y = 1202
        for ex in data.get('exercises', [])[:2]:
            if ex.get('code'):
                draw.text((190, y), ex.get('code',''), font=self.fonts.gothic(17), fill=(80,80,80))
                y += 24
            n = ex.get('number')
            if n is not None:
                draw.text((190, y), f'{n}.', font=self.fonts.bold(24), fill=TEXT_BLACK)
                x = 235
            else:
                x = 190
            y = self.draw_blocks(page, draw, ex.get('blocks', []), x, y, 1070, text_size=23, math_size=22)
            y += 34
        return page

    def draw_problem(self, page: Image.Image, draw: ImageDraw.ImageDraw, problem: Dict[str, Any], x: int, y: int, width: int) -> int:
        if problem.get('number') is not None:
            draw.text((x, y), f"{problem.get('number')}", font=self.fonts.bold(28), fill=TEXT_BLACK)
        if problem.get('code'):
            draw.text((x+50, y+4), problem.get('code',''), font=self.fonts.gothic(18), fill=(80,80,80))
        y += 36
        return self.draw_blocks(page, draw, problem.get('blocks', []), x+40, y, width-50, text_size=23, math_size=22)

    def measure_problem(self, problem: Dict[str, Any], width: int) -> int:
        return 44 + self.block_height(problem.get('blocks', []), width-50, text_size=23, math_size=22) + 20

    def render_level_pages(self, ptype: str, data: Dict[str, Any]) -> List[Image.Image]:
        shell = f'{ptype}_shell.png'
        cont = 'level1_continuation_shell.png' if ptype == 'level1' else ('level2_continuation_shell.png' if ptype == 'level2' else shell)
        problems = list(data.get('problems', []))
        pages = []
        first = True
        while problems:
            page = self.load_shell(shell if first else cont)
            draw = ImageDraw.Draw(page)
            start_y = 210 if first else 135
            end_y = 1695
            x = 145; width = 1220
            selected = []
            total = 0
            for p in problems:
                h = self.measure_problem(p, width)
                if selected and total + h + 24*len(selected) > end_y - start_y:
                    break
                selected.append(p); total += h
            if not selected:
                selected = [problems[0]]
            problems = problems[len(selected):]
            free = max(30, end_y - start_y - total)
            gap = max(22, min(86, free // (len(selected)+1)))
            y = start_y + gap
            for p in selected:
                y = self.draw_problem(page, draw, p, x, y, width)
                y += gap
            pages.append(page)
            first = False
        return pages or [self.load_shell(shell)]

    def render_past_exam(self, data: Dict[str, Any]) -> Image.Image:
        page = self.load_shell('past_exam_shell.png')
        draw = ImageDraw.Draw(page)
        self.draw_blocks(page, draw, data.get('trend_blocks', []), 310, 235, 950, text_size=23, math_size=24)
        prob = data.get('problem', {})
        y = 486
        if prob.get('year_tag'):
            draw.text((1120, 437), prob.get('year_tag',''), font=self.fonts.gothic(19), fill=(255,255,255))
        if prob.get('code'):
            draw.text((205, y), prob.get('code',''), font=self.fonts.gothic(17), fill=(80,80,80)); y += 24
        y = self.draw_blocks(page, draw, prob.get('blocks', []), 205, y, 1050, text_size=23, math_size=22)
        self.draw_blocks(page, draw, data.get('intent_blocks', []), 318, 706, 970, text_size=23, math_size=24)
        self.draw_blocks(page, draw, data.get('solution_blocks', []), 285, 770, 1030, text_size=23, math_size=24)
        return page

    def render_document(self, data: Dict[str, Any], out_dir: Path):
        self.validate_data(data)
        out_dir.mkdir(parents=True, exist_ok=True)
        preview = out_dir / 'previews'; preview.mkdir(exist_ok=True)
        pages: List[Image.Image] = []
        for p in data.get('pages', []):
            t = p.get('type')
            if t == 'example_exercise': pages.append(self.render_example_exercise(p))
            elif t in ('level1','level2','level3'): pages.extend(self.render_level_pages(t, p))
            elif t == 'past_exam': pages.append(self.render_past_exam(p))
            else: raise ValueError(f'알 수 없는 페이지 유형: {t}')
        paths = []
        for i, im in enumerate(pages, 1):
            path = preview / f'page_{i:03d}.png'
            im.save(path); paths.append(path)
        pdf = out_dir / f"{data.get('document_title','suddak_output')}.pdf"
        self.save_pdf(pages, pdf)
        return paths, pdf

# SUDDAK 조판 프로그램 v3

v2 출력이 원본 수특 조판과 크게 어긋난 문제를 고치기 위해 다시 만든 버전입니다.

## 핵심 변경
- 글꼴 설정을 `font_config.json`으로 분리
- 사용자가 제공한 폰트 파일을 `fonts/` 폴더에 직접 넣는 구조
- 수식은 일반 텍스트가 아니라 matplotlib mathtext 이미지로 렌더링
- 선택지를 원본처럼 가로 균등 배치
- 유제 내부 회색 배경 제거
- 예제/유제/Level/대표기출의 기본 좌표 재조정
- 그래프 자동 생성 기능 유지

## 폰트 넣는 법
폰트 파일은 저작권 문제로 이 ZIP에 포함하지 않습니다. 사용자가 직접 넣어야 합니다.

권장 구조:

```text
fonts/
├─ body.ttf          # 본문용 바탕 계열
├─ gothic.ttf        # 고딕 계열
└─ gothic_bold.ttf   # 굵은 고딕 계열
```

넣은 뒤 `font_config.json`을 확인하세요.

윈도우에서 폰트를 넣지 않아도 기본적으로 `C:/Windows/Fonts/malgun.ttf`, `malgunbd.ttf`를 fallback으로 사용합니다.
다만 네가 원하는 수특 느낌을 내려면 반드시 네가 준 본문/고딕 폰트를 `fonts/`에 넣는 것이 좋습니다.

## 설치
```bat
pip install -r requirements.txt
```

## 샘플 실행
```bat
render_sample.bat
```

결과:

```text
output/generated_v3/sample_math_booklet_v3.pdf
output/generated_v3/previews/
```

## GUI 실행
```bat
run_gui.bat
```

## 입력 JSON
샘플은 `samples/sample_document_v3.json` 참고.
GPT 요청용 양식은 `GPT_JSON_REQUEST_TEMPLATE_v3.md` 참고.

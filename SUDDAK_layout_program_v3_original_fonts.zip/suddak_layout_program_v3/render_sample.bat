@echo off
cd /d %~dp0
python app\main.py --input samples\sample_document_v3.json --output output\generated_v3
pause

# GPT에게 수딱 조판 JSON 생성을 요청할 때 붙여넣을 양식

아래 지시를 그대로 사용하세요.

```text
첨부한 수딱 조판 프로그램 v3의 JSON 규격 `suddak-layout-v3`을 엄격히 지켜서 문제 JSON을 작성해 줘.
반드시 JSON 하나만 출력하고, 설명 문장·마크다운·코드블록은 출력하지 마.

중요 규칙:
1. 최상위 schema_version은 반드시 "suddak-layout-v3".
2. pages 배열의 각 원소 type은 다음 중 하나만 사용:
   - example_exercise
   - level1
   - level2
   - level3
   - past_exam
3. 수식은 일반 텍스트 안에 섞지 말고 가능한 display_math 블록으로 분리.
4. 선택지는 반드시 choices 블록으로 작성.
5. 그래프가 필요한 문항은 figure 블록을 사용.
6. 도형 파일이 필요한 문항은 figure 블록의 path를 사용.
7. 문제 하나의 본문은 blocks 배열로 구성.
8. 한글 본문은 text 블록, 긴 수식은 display_math 블록으로 분리.
9. 객관식은 choices items 5개를 작성.
10. 답과 해설이 필요한 경우 solution_blocks에 작성.
```

## 기본 최상위 구조

```json
{
  "schema_version": "suddak-layout-v3",
  "document_title": "unit07_custom",
  "book": "2027 수능특강 미적분 변형",
  "unit_code": "07",
  "pages": []
}
```

## 예제/유제 페이지 구조

```json
{
  "type": "example_exercise",
  "example_title": "정적분과 넓이",
  "example_blocks": [
    {"type": "text", "content": "문제 본문을 작성한다."},
    {"type": "display_math", "latex": "\\int_0^1 x^2\\,dx"},
    {"type": "choices", "items": ["\\frac13", "\\frac12", "1", "2", "3"]}
  ],
  "guide_blocks": [
    {"type": "text", "content": "길잡이 내용을 작성한다."}
  ],
  "solution_blocks": [
    {"type": "display_math", "latex": "\\int_0^1 x^2\\,dx=\\frac13"}
  ],
  "exercises": [
    {
      "number": 1,
      "code": "[SUD-07-001]",
      "blocks": [
        {"type": "text", "content": "유제 본문"},
        {"type": "choices", "items": ["1", "2", "3", "4", "5"]}
      ]
    },
    {
      "number": 2,
      "code": "[SUD-07-002]",
      "blocks": [
        {"type": "text", "content": "유제 본문"},
        {"type": "choices", "items": ["1", "2", "3", "4", "5"]}
      ]
    }
  ]
}
```

## Level 페이지 구조

```json
{
  "type": "level2",
  "problems": [
    {
      "number": 1,
      "code": "[SUD-L2-001]",
      "blocks": [
        {"type": "text", "content": "문제 본문"},
        {"type": "display_math", "latex": "f(x)=x^2-2x+1"},
        {"type": "choices", "items": ["1", "2", "3", "4", "5"]}
      ]
    }
  ]
}
```

## 그래프 블록

```json
{
  "type": "figure",
  "figure_type": "function_graph",
  "width_px": 450,
  "height_px": 280,
  "x_min": -1,
  "x_max": 3,
  "y_min": -1,
  "y_max": 5,
  "functions": [
    {"expr": "x**2", "label": "y=x^2"},
    {"expr": "2*x", "label": "y=2x"}
  ],
  "points": [
    {"x": 0, "y": 0, "label": "O"},
    {"x": 2, "y": 4, "label": "A"}
  ]
}
```

## 외부 도형 파일 블록

```json
{
  "type": "figure",
  "path": "figures/U07_L2_03.png",
  "width_px": 450,
  "height_px": 280,
  "align": "center"
}
```
